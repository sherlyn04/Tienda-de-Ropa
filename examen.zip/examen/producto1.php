<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Luz Clarita</title>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/toastify-js/src/toastify.min.css">
    <link rel="stylesheet" href="estilos.css">

    <script src="js/jquery-3.2.1.js"></script>
    <script src="js/script.js"></script>
</head>

<body>
    <div class="wrap">
        <header class="header-mobile">
            <h1 class="logo">LuzClarita</h1>
            <button class="open-menu" id="open-menu">
            <i class="bi bi-list"></i>
            </button>
        </header>
        <aside>
            <button class="close-menu" id="close-menu">
                <i class="bi bi-x"></i>
            </button>
            <header>
                <h1 class="logo">LuzClarita</h1>
            </header>
            <nav>
                <ul class="menu">
                    <a href="#" category="all" class="category_item  "><i class="bi bi-hand-index-thumb-fill"></i> Todos los productos</a>
                    <a href="#" category="mujer" class="category_item "><i class="bi bi-hand-index-thumb"></i> Mujer</a>
                    <a href="#" category="hombre" class="category_item "><i class="bi bi-hand-index-thumb"></i> Hombre</a>
                    <a href="#" category="niños" class="category_item "><i class="bi bi-hand-index-thumb"></i> Niños</a>
                    <a href="#" category="ropa" class="category_item"><i class="bi bi-hand-index-thumb"></i> Ropa Interior</a>
                    <a href="#" category="tendencia" class="category_item"><i class="bi bi-hand-index-thumb"></i> Tendencia </a>
                    <a href="#" category="descuentos" class="category_item"><i class="bi bi-hand-index-thumb"></i> Descuentos </a>
                    <li>
                        <a class="category_item boton-sesion" href="./inicio.php">
                            <i class="bi bi-arrow-return-left"></i> Atrás 
                        </a>
                    </li>

                </ul>
            </nav>

            <footer>
                <p class="texto-footer">© Sherlyn Sañay</p>
            </footer>
        </aside>
        <main>
                <h2 class="titulo-principal" id="titulo-principal">Todos los productos</h2>
                <input type="search" class="buscador form-control mb-3" id="buscador" name="buscador">
                <div id="contenedor-productos" class="contenedor-productos">
                    <?php
                        
                        $conexion = mysqli_connect("localhost", "root", "", "proyecto");
                        $query = mysqli_query($conexion, "SELECT * FROM productos WHERE Tipo = 'mujer'");

                        while ($row = mysqli_fetch_array($query)) {
                            echo "<div class='product-item' category='mujer'>";
                            echo "<img class='producto-imagen' src='data:image/jpg;base64," . base64_encode($row['imagen']) . "' alt='Imagen del producto'>";
                            echo "<div class='producto-detalles'>";
                            echo "<h3 class='nombre'>" . $row['Nombre'] . "</h3>";
                            echo "<p class='precio'>Precio: $" . $row['Precio'] . "</p>";
                            echo "<p class='talla'>Talla: " . $row['Talla'] . "</p>";
                            echo "<p class='descuento'>Descuento: " . $row['Descuento'] . "% </p>";
                            echo "</div>";
                            echo "</div>";
                        }
                    ?>

                    <?php
                        
                        $conexion = mysqli_connect("localhost", "root", "", "proyecto");
                        $query = mysqli_query($conexion, "SELECT * FROM productos WHERE Tipo = 'hombre'");

                        while ($row = mysqli_fetch_array($query)) {
                            echo "<div class='product-item' category='hombre'>";
                            echo "<img class='producto-imagen' src='data:image/jpg;base64," . base64_encode($row['imagen']) . "' alt='Imagen del producto'>";
                            echo "<div class='producto-detalles'>";
                            echo "<h3 class='nombre'>" . $row['Nombre'] . "</h3>";
                            echo "<p class='precio'>Precio: $" . $row['Precio'] . "</p>";
                            echo "<p class='talla'>Talla: " . $row['Talla'] . "</p>";
                            echo "<p class='descuento'>Descuento: " . $row['Descuento'] . "%</p>";
                            echo "</div>";
                            echo "</div>";
                        }
                    ?>

                    <?php
                        
                        $conexion = mysqli_connect("localhost", "root", "", "proyecto");
                        $query = mysqli_query($conexion, "SELECT * FROM productos WHERE Tipo = 'niños'");

                        while ($row = mysqli_fetch_array($query)) {
                            echo "<div class='product-item' category='niños'>";
                            echo "<img class='producto-imagen' src='data:image/jpg;base64," . base64_encode($row['imagen']) . "' alt='Imagen del producto'>";
                            echo "<div class='producto-detalles'>";
                            echo "<h3 class='nombre'>" . $row['Nombre'] . "</h3>";
                            echo "<p class='precio'>Precio: $" . $row['Precio'] . "</p>";
                            echo "<p class='talla'>Talla: " . $row['Talla'] . "</p>";
                            echo "<p class='descuento'>Descuento: " . $row['Descuento'] . "%</p>";
                            echo "</div>";
                            echo "</div>";
                        }
                    ?>

                    <?php
                        
                        $conexion = mysqli_connect("localhost", "root", "", "proyecto");
                        $query = mysqli_query($conexion, "SELECT * FROM productos WHERE Tipo = 'ropa'");

                        while ($row = mysqli_fetch_array($query)) {
                            echo "<div class='product-item' category='ropa'>";
                            echo "<img class='producto-imagen' src='data:image/jpg;base64," . base64_encode($row['imagen']) . "' alt='Imagen del producto'>";
                            echo "<div class='producto-detalles'>";
                            echo "<h3 class='nombre'>" . $row['Nombre'] . "</h3>";
                            echo "<p class='precio'>Precio: $" . $row['Precio'] . "</p>";
                            echo "<p class='talla'>Talla: " . $row['Talla'] . "</p>";
                            echo "<p class='descuento'>Descuento: " . $row['Descuento'] . "%</p>";
                            echo "</div>";
                            echo "</div>";
                        }
                    ?>

                    <?php
                        
                        $conexion = mysqli_connect("localhost", "root", "", "proyecto");
                        $query = mysqli_query($conexion, "SELECT * FROM productos WHERE Tipo = 'tendencia'");

                        while ($row = mysqli_fetch_array($query)) {
                            echo "<div class='product-item' category='tendencia'>";
                            echo "<img class='producto-imagen' src='data:image/jpg;base64," . base64_encode($row['imagen']) . "' alt='Imagen del producto'>";
                            echo "<div class='producto-detalles'>";
                            echo "<h3 class='nombre'>" . $row['Nombre'] . "</h3>";
                            echo "<p class='precio'>Precio: $" . $row['Precio'] . "</p>";
                            echo "<p class='talla'>Talla: " . $row['Talla'] . "</p>";
                            echo "<p class='descuento'>Descuento: " . $row['Descuento'] . "%</p>";
                            echo "</div>";
                            echo "</div>";
                        }
                    ?>

                    <?php
                        
                        $conexion = mysqli_connect("localhost", "root", "", "proyecto");
                        $query = mysqli_query($conexion, "SELECT * FROM productos WHERE Tipo = 'descuentos'");

                        while ($row = mysqli_fetch_array($query)) {
                            echo "<div class='product-item' category='descuentos'>";
                            echo "<img class='producto-imagen' src='data:image/jpg;base64," . base64_encode($row['imagen']) . "' alt='Imagen del producto'>";
                            echo "<div class='producto-detalles'>";
                            echo "<h3 class='nombre'>" . $row['Nombre'] . "</h3>";
                            echo "<p class='precio'>Precio: $" . $row['Precio'] . "</p>";
                            echo "<p class='talla'>Talla: " . $row['Talla'] . "</p>";
                            echo "<p class='descuento'>Descuento: " . $row['Descuento'] . "%</p>";
                            echo "</div>";
                            echo "</div>";
                        }
                    ?>
                </div>
        </main>

    </div>
    <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/toastify-js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="js/search.js"></script>
    <script src="./js/script.js"></script>
</body>

</html>
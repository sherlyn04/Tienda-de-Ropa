<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LuzClarita</title>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/toastify-js/src/toastify.min.css">
    <link rel="stylesheet" href="estilo.css">
    <script src="js/jquery-3.2.1.js"></script>

</head>

<body>
    <header class="header">
        <div class="menu container">
            <a href="#" class="logo">LuzClarita</a>
            <input type="checkbox" id="menu" />
            <label for="menu">
                <img src ="img/inicio/menu.png" class ="menu-icono" alt="">
            </label>

            <nav class="navbar">
                <ul>
                    <li><a href="#">Inicio</a></li>
                    <li><a class="producto1" href="producto1.php">Productos </a></li>
                    <li><a href="sesion.php">Iniciar Sesión</a></li>
                </ul>
            </nav>
        </div>
        <div class="header-content container">
            <div class="header-txt">
                <h1>FINAL DE TEMPORADA</h1>
                <p>
                    ¡Es momento de aprovechar!<br> Descuentos increíbles de hasta 50% off en el outlet.
                </p>
                <a href="producto1.php" class="btn-1">...</a>
            </div>

            <div class="header-img">
                <figure>
                    <img src="img/inicio/collage.png" alt="">
                    <div class="capa">
                        <h3>50% Descuento </h3>
                    </div>
                </figure>
            </div>
        </div>
    </header>

    <section class="general container">
        <div class="general-1">
            <div class="general-card1">
                <img src="img/inicio/coleccion1.jpg" alt="">
                <a href="#" class="btn-coleccion">Pantalón Holgado</a>
            </div>

            <div class="general-card2">
                <img src="img/inicio/coleccion2.jpg" alt="">
                <a href="#" class="btn-coleccion">Falda ajustada</a>
            </div>

            <div class="general-card3">
                <img src="img/inicio/coleccion3.jpg" alt="">
                <a href="#" class="btn-coleccion">Conjunto de camisa y short</a>
            </div>
        </div>
        <div class="general-2">
            <h2>Nueva colección</h2>
            <P>
                Descubre la Elegancia Renovada en Nuestra Última Colección! Moda Exclusiva para Mujeres, Hombres y Niños.
            </P>
            <a href="producto1.php" class="btn-2">...</a>
        </div>
    </section>

    <section class="general container">

        <div class="general-2">
            <h2>Tendencias</h2>
            <p>
                Nos dedicamos a ofrecer una cuidada selección de ropa que reflejen las últimas tendencias de la moda.
            </p>
            <a href="producto1.php" class="btn-2">...</a>
        </div>

        <div class="general-1">
            <div class="general-card bg-1">
            </div>

            <div class="general-card bg-2">
            </div>

            <div class="general-card bg-3">
            </div>
        </div>
    </section>

    <main class="information">
        <div class="information-content container">
            <div class="information-1">
                <h3>ACERCA DE</h3>
                <p>
                    Nuestra misión es proporcionarte una experiencia de compra excepcional, donde la calidad, la comodidad y el estilo se unen.
                </p>
                <a href="#" class="bton-2">Contáctenos<br></a>
                <a href="#" class="bton-2">Nuestra Historia</a>
            </div>

            <div class="information-1">
                <h3>Servicio al Cliente</h3>
                <p>
                    Gracias por confiar en nosotros para satisfacer tus necesidades de moda.
                </p>
                <a href="#" class="bton-2">Mi cuenta<br></a>
                <a href="#" class="bton-2">Entrega</a>
            </div>


            <div class="information-1">
                <h3>Terminos</h3>
                <p>
                    Aceptas cumplir con los siguientes términos y condiciones, así como todas las leyes y regulaciones aplicables.
                </p>
                <a href="#" class="bton-2">Términos y condiciones<br></a>
                <a href="#" class="bton-2">Política</a>
            </div>

        </div>
    </main>

    <script src="script.js"></script>
</body>

</html>
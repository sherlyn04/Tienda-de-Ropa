<?php
include('db.php');
$usuario=$_POST['usuario'];
$password=$_POST['contraseña'];



$consulta="SELECT*FROM usuarios where usuario='$usuario' and contraseña='$password'";
$resultado=mysqli_query($conexion,$consulta);

$filas=mysqli_num_rows($resultado);

if($filas){
  
    header("location:index.php");

}else{
    ?>
    <?php
    include("sesion.php");

  ?>
  <h1 class="bad">ERROR DE AUTENTIFICACION</h1>
  <?php
}
mysqli_free_result($resultado);
mysqli_close($conexion);

<?php

$conexion=mysqli_connect("localhost","root","","proyecto")or die(
    "error de conexion");
?>
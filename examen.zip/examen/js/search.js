document.addEventListener('DOMContentLoaded', function () {
    const buscador = document.getElementById('buscador');
    const productos = document.querySelectorAll('.product-item');

    buscador.addEventListener('input', function () {
        const busqueda = buscador.value.toLowerCase();

        productos.forEach(producto => {
            const nombreProducto = producto.querySelector('.nombre').textContent.toLowerCase();
            if (nombreProducto.includes(busqueda)) {
                producto.style.display = 'block';
            } else {
                producto.style.display = 'none';
            }
        });
    });
});


<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="css/login1.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.0.0/animate.min.css">
</head>
<body>
    <section>
        <class="fondo">
            <form action="validar.php" method="post">    
                <div class="login">
                    <h2>Login</h2> 
                    <div class="input-box">
                        <input type="text" placeholder="Nombre de Usuario" name="usuario">
                    </div>
                    
                    <div class="input-box">
                        <input type="password" placeholder="Contraseña" name="contraseña">
                    </div>

                    <div class="input-box">
                        <input type="submit" value="Iniciar Sesión">
                    </div>
                </div> 
            </form>    
</body>
</html>